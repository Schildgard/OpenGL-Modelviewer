var searchData=
[
  ['quick_2emd_0',['quick.md',['../quick_8md.html',1,'']]]
];
